import { motion } from 'framer-motion'
import { Zap, ShoppingBag, Megaphone, Settings, Star } from 'lucide-react'
import { useReviewStore } from '../../store/reviewStore'
import clsx from 'clsx'

const CATEGORY_STYLES = {
  product: { color: '#00f5ff', icon: ShoppingBag, label: 'Product' },
  marketing: { color: '#bf5af2', icon: Megaphone, label: 'Marketing' },
  operations: { color: '#ffb800', icon: Settings, label: 'Operations' },
  quality: { color: '#ff3b3b', icon: Star, label: 'Quality Control' },
}

const PRIORITY_STYLES = {
  1: { label: 'P1 Critical', color: '#ff3b3b', bg: 'rgba(255,59,59,0.1)', border: 'rgba(255,59,59,0.3)' },
  2: { label: 'P2 High', color: '#ffb800', bg: 'rgba(255,184,0,0.08)', border: 'rgba(255,184,0,0.25)' },
  3: { label: 'P3 Medium', color: '#00f5ff', bg: 'rgba(0,245,255,0.06)', border: 'rgba(0,245,255,0.2)' },
  4: { label: 'P4 Low', color: '#8b949e', bg: 'rgba(139,148,158,0.06)', border: 'rgba(139,148,158,0.2)' },
}

export default function RecommendationsTab() {
  const { report } = useReviewStore()
  if (!report) return null

  const recommendations = report.recommendations || []

  const grouped = { 1: [], 2: [], 3: [], 4: [] }
  recommendations.forEach(r => {
    const p = Math.min(4, Math.max(1, r.priority))
    grouped[p].push(r)
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-white">Actionable Recommendations</h2>
          <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.45)' }}>
            LLM-generated, data-driven insights for product and marketing teams
          </p>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3, 4].map(p => {
            const count = grouped[p].length
            if (!count) return null
            const { label, color, bg, border } = PRIORITY_STYLES[p]
            return (
              <div key={p} className="px-3 py-1.5 rounded-lg text-xs font-medium"
                style={{ background: bg, border: `1px solid ${border}`, color }}>
                {count} {label}
              </div>
            )
          })}
        </div>
      </div>

      {recommendations.length === 0 && (
        <div className="glass-card p-12 text-center">
          <Zap size={40} className="mx-auto mb-4" style={{ color: 'rgba(255,255,255,0.2)' }} />
          <p style={{ color: 'rgba(255,255,255,0.4)' }}>No recommendations generated yet</p>
        </div>
      )}

      <div className="space-y-4">
        {recommendations.map((rec, i) => {
          const p = Math.min(4, Math.max(1, rec.priority))
          const { color: pColor, bg: pBg, border: pBorder, label: pLabel } = PRIORITY_STYLES[p]
          const catStyle = CATEGORY_STYLES[rec.category] || CATEGORY_STYLES.product
          const CatIcon = catStyle.icon

          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="glass-card p-6"
              style={{ borderColor: pBorder, background: pBg }}
            >
              <div className="flex items-start gap-5">
                {/* Priority badge */}
                <div className="flex flex-col items-center gap-2 flex-shrink-0">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center font-bold font-mono text-sm"
                    style={{ background: `${pColor}15`, border: `1px solid ${pColor}30`, color: pColor }}>
                    P{p}
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  {/* Header */}
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <h3 className="font-display font-semibold text-white">{rec.title}</h3>
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded text-xs"
                      style={{ background: `${catStyle.color}12`, color: catStyle.color, border: `1px solid ${catStyle.color}25` }}>
                      <CatIcon size={10} />
                      {catStyle.label}
                    </div>
                    {rec.affected_feature && (
                      <span className="px-2 py-0.5 rounded text-xs font-mono capitalize"
                        style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.4)' }}>
                        #{rec.affected_feature.replace(/_/g, '-')}
                      </span>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-sm leading-relaxed mb-3" style={{ color: 'rgba(255,255,255,0.65)' }}>
                    {rec.description}
                  </p>

                  {/* 3-col detail grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="rounded-xl p-3"
                      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                      <div className="text-xs font-medium mb-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>📊 Supporting Data</div>
                      <div className="text-xs" style={{ color: 'rgba(255,255,255,0.65)' }}>{rec.supporting_data}</div>
                    </div>
                    <div className="rounded-xl p-3"
                      style={{ background: 'rgba(0,245,255,0.03)', border: '1px solid rgba(0,245,255,0.1)' }}>
                      <div className="text-xs font-medium mb-1.5" style={{ color: '#00f5ff' }}>⚡ Suggested Action</div>
                      <div className="text-xs" style={{ color: 'rgba(255,255,255,0.65)' }}>{rec.suggested_action}</div>
                    </div>
                    <div className="rounded-xl p-3"
                      style={{ background: 'rgba(57,255,20,0.03)', border: '1px solid rgba(57,255,20,0.1)' }}>
                      <div className="text-xs font-medium mb-1.5" style={{ color: '#39ff14' }}>🎯 Estimated Impact</div>
                      <div className="text-xs" style={{ color: 'rgba(255,255,255,0.65)' }}>{rec.estimated_impact}</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Category summary */}
      <div className="glass-card p-6">
        <h3 className="font-display font-semibold text-white mb-4">By Category</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(CATEGORY_STYLES).map(([key, { color, icon: Icon, label }]) => {
            const count = recommendations.filter(r => r.category === key).length
            return (
              <div key={key} className="text-center p-4 rounded-xl"
                style={{ background: `${color}08`, border: `1px solid ${color}20` }}>
                <Icon size={20} className="mx-auto mb-2" style={{ color }} />
                <div className="text-2xl font-bold font-display" style={{ color }}>{count}</div>
                <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.45)' }}>{label}</div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
