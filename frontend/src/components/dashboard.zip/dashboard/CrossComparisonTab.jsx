import { motion } from 'framer-motion'
import { useReviewStore } from '../../store/reviewStore'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend, Cell
} from 'recharts'
import { Trophy, TrendingDown, Globe, Layers } from 'lucide-react'

const CATEGORY_COLORS = [
  '#00f5ff', '#bf5af2', '#39ff14', '#ffb800', '#ff006e', '#ff3b3b', '#8b949e'
]

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="px-3 py-2 rounded-xl text-xs"
      style={{ background: 'rgba(22,27,34,0.95)', border: '1px solid rgba(0,245,255,0.2)', backdropFilter: 'blur(12px)' }}>
      {label && <div className="font-semibold text-white mb-1">{label}</div>}
      {payload.map(p => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.fill || p.color }} />
          <span style={{ color: 'rgba(255,255,255,0.6)' }}>{p.name}:</span>
          <span className="font-semibold text-white">{p.value}%</span>
        </div>
      ))}
    </div>
  )
}

export default function CrossComparisonTab() {
  const { getCrossComparisonData } = useReviewStore()
  const data = getCrossComparisonData()

  if (!data || !data.categories?.length) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
          style={{ background: 'rgba(0,245,255,0.08)', border: '1px solid rgba(0,245,255,0.2)' }}>
          <Layers size={28} style={{ color: '#00f5ff' }} />
        </div>
        <h3 className="font-display font-semibold text-white mb-2">Cross-Comparison Not Available</h3>
        <p className="text-sm max-w-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>
          Upload reviews with multiple product categories (at least 2) to enable cross-product comparison.
        </p>
      </div>
    )
  }

  const { categories, sentiment_by_category, review_count_by_category,
    best_category, worst_category, bot_rate_by_category } = data

  // Sentiment bar chart data
  const sentimentBarData = categories.map((cat, i) => ({
    category: cat.length > 12 ? cat.slice(0, 12) + '…' : cat,
    fullName: cat,
    Positive: Math.round((sentiment_by_category[cat]?.positive || 0) * 100),
    Negative: Math.round((sentiment_by_category[cat]?.negative || 0) * 100),
    Neutral: Math.round((sentiment_by_category[cat]?.neutral || 0) * 100),
    color: CATEGORY_COLORS[i % CATEGORY_COLORS.length],
  }))

  // Radar chart data — positive score by category
  const radarData = ['positive', 'negative', 'neutral', 'mixed'].map(metric => {
    const entry = { metric: metric.charAt(0).toUpperCase() + metric.slice(1) }
    categories.forEach(cat => {
      entry[cat] = Math.round((sentiment_by_category[cat]?.[metric] || 0) * 100)
    })
    return entry
  })

  return (
    <div className="space-y-6">
      {/* Best/Worst Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card p-5 flex items-center gap-4"
          style={{ border: '1px solid rgba(57,255,20,0.25)' }}
        >
          <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(57,255,20,0.12)', border: '1px solid rgba(57,255,20,0.3)' }}>
            <Trophy size={22} style={{ color: '#39ff14' }} />
          </div>
          <div>
            <div className="text-xs mb-1" style={{ color: 'rgba(255,255,255,0.4)' }}>Best Performing Category</div>
            <div className="font-display font-bold text-xl" style={{ color: '#39ff14' }}>
              {best_category || 'N/A'}
            </div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
              {Math.round((sentiment_by_category[best_category]?.positive || 0) * 100)}% positive sentiment
              · {review_count_by_category[best_category] || 0} reviews
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card p-5 flex items-center gap-4"
          style={{ border: '1px solid rgba(255,59,59,0.25)' }}
        >
          <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(255,59,59,0.12)', border: '1px solid rgba(255,59,59,0.3)' }}>
            <TrendingDown size={22} style={{ color: '#ff3b3b' }} />
          </div>
          <div>
            <div className="text-xs mb-1" style={{ color: 'rgba(255,255,255,0.4)' }}>Needs Most Attention</div>
            <div className="font-display font-bold text-xl" style={{ color: '#ff3b3b' }}>
              {worst_category || 'N/A'}
            </div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
              {Math.round((sentiment_by_category[worst_category]?.negative || 0) * 100)}% negative sentiment
              · {review_count_by_category[worst_category] || 0} reviews
            </div>
          </div>
        </motion.div>
      </div>

      {/* Category Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {categories.map((cat, i) => {
          const color = CATEGORY_COLORS[i % CATEGORY_COLORS.length]
          const pos = Math.round((sentiment_by_category[cat]?.positive || 0) * 100)
          const neg = Math.round((sentiment_by_category[cat]?.negative || 0) * 100)
          const botRate = Math.round((bot_rate_by_category[cat] || 0) * 100)
          const count = review_count_by_category[cat] || 0
          const isBest = cat === best_category
          const isWorst = cat === worst_category

          return (
            <motion.div
              key={cat}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="glass-card p-4"
              style={{ border: isBest ? '1px solid rgba(57,255,20,0.3)' : isWorst ? '1px solid rgba(255,59,59,0.3)' : undefined }}
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-lg flex items-center justify-center"
                  style={{ background: `${color}15`, border: `1px solid ${color}30` }}>
                  <Globe size={11} style={{ color }} />
                </div>
                <span className="text-xs font-semibold text-white truncate">{cat}</span>
                {isBest && <span className="text-xs ml-auto">🏆</span>}
                {isWorst && <span className="text-xs ml-auto">⚠️</span>}
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span style={{ color: 'rgba(255,255,255,0.4)' }}>Positive</span>
                  <span style={{ color: '#39ff14' }}>{pos}%</span>
                </div>
                <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pos}%` }}
                    transition={{ duration: 0.8, delay: i * 0.06 }}
                    className="h-full rounded-full"
                    style={{ background: '#39ff14' }}
                  />
                </div>
                <div className="flex justify-between text-xs">
                  <span style={{ color: 'rgba(255,255,255,0.4)' }}>Negative</span>
                  <span style={{ color: '#ff3b3b' }}>{neg}%</span>
                </div>
                <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${neg}%` }}
                    transition={{ duration: 0.8, delay: i * 0.06 + 0.1 }}
                    className="h-full rounded-full"
                    style={{ background: '#ff3b3b' }}
                  />
                </div>
                <div className="flex justify-between text-xs mt-1 pt-1" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                  <span style={{ color: 'rgba(255,255,255,0.35)' }}>{count} reviews</span>
                  <span style={{ color: botRate > 20 ? '#ff3b3b' : 'rgba(255,255,255,0.35)' }}>
                    {botRate}% bots
                  </span>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Sentiment Comparison Bar Chart */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card p-6"
      >
        <h3 className="font-display font-semibold text-white mb-1">Sentiment by Category</h3>
        <p className="text-xs mb-5" style={{ color: 'rgba(255,255,255,0.35)' }}>
          Side-by-side positive / negative comparison across product categories
        </p>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={sentimentBarData} barSize={14} barGap={3}>
            <XAxis dataKey="category" tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.4)' }} />
            <YAxis tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.4)' }} unit="%" />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)' }} />
            <Bar dataKey="Positive" fill="#39ff14" radius={[3, 3, 0, 0]} fillOpacity={0.85} />
            <Bar dataKey="Negative" fill="#ff3b3b" radius={[3, 3, 0, 0]} fillOpacity={0.85} />
            <Bar dataKey="Neutral" fill="#8b949e" radius={[3, 3, 0, 0]} fillOpacity={0.7} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Radar Chart */}
      {radarData.length > 0 && categories.length >= 2 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-card p-6"
        >
          <h3 className="font-display font-semibold text-white mb-1">Sentiment Profile Radar</h3>
          <p className="text-xs mb-5" style={{ color: 'rgba(255,255,255,0.35)' }}>
            Multi-dimensional sentiment comparison per category
          </p>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(255,255,255,0.08)" />
              <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.5)' }} />
              {categories.slice(0, 4).map((cat, i) => (
                <Radar
                  key={cat}
                  name={cat}
                  dataKey={cat}
                  stroke={CATEGORY_COLORS[i]}
                  fill={CATEGORY_COLORS[i]}
                  fillOpacity={0.08}
                  strokeWidth={1.5}
                />
              ))}
              <Legend wrapperStyle={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)' }} />
              <Tooltip
                contentStyle={{ background: 'rgba(22,27,34,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                formatter={(val) => [`${val}%`, '']}
              />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>
      )}
    </div>
  )
}
