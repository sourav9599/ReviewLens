import { motion, AnimatePresence } from 'framer-motion'
import { useReviewStore } from '../../store/reviewStore'
import {
  Brain, GitBranch, RefreshCw, AlertTriangle, CheckCircle2,
  ArrowRight, Cpu, Repeat, TrendingUp, Zap, Shield, Globe,
  BarChart3, FileText, Smile
} from 'lucide-react'

const AGENT_COLORS = {
  PreprocessingAgent: '#00f5ff',
  EmojiAgent: '#ffb800',
  'OrchestratorAgent (Pre)': '#bf5af2',
  DeduplicationAgent: '#39ff14',
  'OrchestratorAgent (Post-Dedup)': '#bf5af2',
  SentimentAgent: '#ff006e',
  'OrchestratorAgent (Post-Sentiment)': '#bf5af2',
  TrendAgent: '#ff3b3b',
  'OrchestratorAgent (Post-Trend)': '#bf5af2',
  RecommendationAgent: '#ffb800',
  CrossComparisonAgent: '#00f5ff',
  ReportAgent: '#39ff14',
}

const AGENT_ICONS = {
  PreprocessingAgent: FileText,
  EmojiAgent: Smile,
  'OrchestratorAgent (Pre)': Brain,
  DeduplicationAgent: Shield,
  'OrchestratorAgent (Post-Dedup)': Brain,
  SentimentAgent: Zap,
  'OrchestratorAgent (Post-Sentiment)': Brain,
  TrendAgent: TrendingUp,
  'OrchestratorAgent (Post-Trend)': Brain,
  RecommendationAgent: BarChart3,
  CrossComparisonAgent: Globe,
  ReportAgent: FileText,
}

const ACTION_COLORS = {
  route: '#00f5ff',
  retry: '#ffb800',
  skip: '#8b949e',
  escalate: '#ff3b3b',
}

const ACTION_ICONS = {
  route: ArrowRight,
  retry: RefreshCw,
  skip: CheckCircle2,
  escalate: AlertTriangle,
}

function AgentNode({ step, index, total }) {
  const isOrchestrator = step.agent.includes('Orchestrator')
  const color = AGENT_COLORS[step.agent] || '#666'
  const Icon = AGENT_ICONS[step.agent] || Cpu
  const isLast = index === total - 1

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.07 }}
      className="flex items-start gap-3"
    >
      {/* Connector line */}
      <div className="flex flex-col items-center flex-shrink-0" style={{ width: 36 }}>
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{
            background: `${color}15`,
            border: `1.5px solid ${color}40`,
            boxShadow: isOrchestrator ? `0 0 14px ${color}30` : 'none',
          }}
        >
          <Icon size={16} style={{ color }} />
        </div>
        {!isLast && (
          <div className="w-px flex-1 mt-1" style={{ background: 'rgba(255,255,255,0.08)', minHeight: 20 }} />
        )}
      </div>

      {/* Content */}
      <div className="flex-1 pb-4">
        <div className="flex items-center gap-2 flex-wrap">
          <span
            className="text-sm font-semibold"
            style={{ color: isOrchestrator ? '#bf5af2' : 'rgba(255,255,255,0.9)' }}
          >
            {step.agent}
          </span>
          <span
            className="px-2 py-0.5 rounded text-xs font-mono"
            style={{
              background: step.output === 'complete' ? 'rgba(57,255,20,0.1)' : 'rgba(255,255,255,0.05)',
              color: step.output === 'complete' ? '#39ff14' : '#8b949e',
              border: `1px solid ${step.output === 'complete' ? 'rgba(57,255,20,0.2)' : 'rgba(255,255,255,0.08)'}`,
            }}
          >
            {step.output}
          </span>
        </div>

        {/* Agent-specific metadata */}
        <div className="flex flex-wrap gap-2 mt-1.5">
          {step.count > 0 && (
            <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
              {step.count} reviews preprocessed
            </span>
          )}
          {step.emojis > 0 && (
            <span className="text-xs" style={{ color: '#ffb800' }}>
              {step.emojis} emojis · {step.reviews_with_emojis} reviews
            </span>
          )}
          {step.duplicates !== undefined && (
            <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
              {step.duplicates} dups · {step.bots} bots
            </span>
          )}
          {step.low_confidence > 0 && (
            <span className="text-xs" style={{ color: '#ffb800' }}>
              ⚠ {step.low_confidence} low-confidence
            </span>
          )}
          {step.avg_confidence > 0 && (
            <span className="text-xs" style={{ color: '#00f5ff' }}>
              avg conf: {(step.avg_confidence * 100).toFixed(0)}%
            </span>
          )}
          {step.alerts > 0 && (
            <span className="text-xs" style={{ color: '#ff3b3b' }}>
              {step.alerts} alerts raised
            </span>
          )}
          {step.recommendations > 0 && (
            <span className="text-xs" style={{ color: '#ffb800' }}>
              {step.recommendations} recommendations
            </span>
          )}
          {step.categories > 0 && (
            <span className="text-xs" style={{ color: '#00f5ff' }}>
              {step.categories} categories compared
            </span>
          )}
          {step.route && step.route !== 'proceed' && (
            <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: 'rgba(255,184,0,0.15)', color: '#ffb800' }}>
              ↺ {step.route}
            </span>
          )}
          {step.decisions > 0 && (
            <span className="text-xs" style={{ color: '#bf5af2' }}>
              {step.decisions} decision(s)
            </span>
          )}
        </div>
      </div>
    </motion.div>
  )
}

function DecisionCard({ decision, index }) {
  const ActionIcon = ACTION_ICONS[decision.action] || ArrowRight
  const actionColor = ACTION_COLORS[decision.action] || '#666'

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="rounded-xl p-4"
      style={{
        background: 'rgba(255,255,255,0.03)',
        border: `1px solid ${actionColor}25`,
      }}
    >
      <div className="flex items-start gap-3">
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
          style={{ background: `${actionColor}15`, border: `1px solid ${actionColor}30` }}
        >
          <ActionIcon size={13} style={{ color: actionColor }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-mono px-2 py-0.5 rounded"
              style={{ background: `${actionColor}15`, color: actionColor }}>
              {decision.action.toUpperCase()}
            </span>
            <span className="text-xs font-mono" style={{ color: 'rgba(255,255,255,0.3)' }}>
              [{decision.phase}]
            </span>
            <span className="text-xs font-mono" style={{ color: 'rgba(255,255,255,0.2)' }}>
              #{decision.decision_id}
            </span>
          </div>
          <div className="text-sm font-medium text-white mb-1">
            {decision.decision.replace(/_/g, ' ')}
          </div>
          <div className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.5)' }}>
            {decision.reason}
          </div>
          {decision.affected_agents?.length > 0 && (
            <div className="flex gap-1.5 mt-2 flex-wrap">
              {decision.affected_agents.map(a => (
                <span key={a} className="text-xs px-1.5 py-0.5 rounded"
                  style={{ background: 'rgba(191,90,242,0.1)', color: '#bf5af2', border: '1px solid rgba(191,90,242,0.2)' }}>
                  → {a}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}

export default function AgentOrchestrationTab() {
  const { getOrchestratorData } = useReviewStore()
  const { decisions, agentTrace, feedbackLoops, pipelineVersion } = getOrchestratorData()

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Pipeline Version', val: pipelineVersion, color: '#00f5ff', sub: 'Agentic Architecture' },
          { label: 'Agents Executed', val: agentTrace.length, color: '#39ff14', sub: 'in directed graph' },
          { label: 'Orchestrator Decisions', val: decisions.length, color: '#bf5af2', sub: 'dynamic routing' },
          { label: 'Feedback Loops', val: feedbackLoops, color: '#ffb800', sub: feedbackLoops > 0 ? 'triggered & resolved' : 'none required' },
        ].map(({ label, val, color, sub }) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-5"
          >
            <div className="font-display font-bold text-3xl mb-1" style={{ color }}>{val}</div>
            <div className="text-sm font-medium text-white">{label}</div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>{sub}</div>
          </motion.div>
        ))}
      </div>

      {/* Feedback Loop Banner */}
      {feedbackLoops > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-4 flex items-center gap-3"
          style={{ border: '1px solid rgba(255,184,0,0.3)', background: 'rgba(255,184,0,0.05)' }}
        >
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(255,184,0,0.15)', border: '1px solid rgba(255,184,0,0.3)' }}>
            <Repeat size={18} style={{ color: '#ffb800' }} />
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: '#ffb800' }}>
              Feedback Loop Triggered × {feedbackLoops}
            </div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.5)' }}>
              The Orchestrator detected high bot rate and re-ran deduplication with a stricter similarity threshold.
              This is true agentic behavior — the system corrected itself without human intervention.
            </div>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Agent Execution Trace */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="glass-card p-6"
        >
          <div className="flex items-center gap-2 mb-5">
            <GitBranch size={16} style={{ color: '#00f5ff' }} />
            <h3 className="font-display font-semibold text-white">Agent Execution Flow</h3>
          </div>
          <div>
            {agentTrace.map((step, i) => (
              <AgentNode key={i} step={step} index={i} total={agentTrace.length} />
            ))}
            {agentTrace.length === 0 && (
              <div className="text-sm text-center py-8" style={{ color: 'rgba(255,255,255,0.3)' }}>
                No agent trace available
              </div>
            )}
          </div>
        </motion.div>

        {/* Orchestrator Decisions */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="glass-card p-6"
        >
          <div className="flex items-center gap-2 mb-5">
            <Brain size={16} style={{ color: '#bf5af2' }} />
            <h3 className="font-display font-semibold text-white">Orchestrator Decision Log</h3>
            <span className="ml-auto text-xs px-2 py-0.5 rounded"
              style={{ background: 'rgba(191,90,242,0.1)', color: '#bf5af2', border: '1px solid rgba(191,90,242,0.2)' }}>
              {decisions.length} decisions
            </span>
          </div>

          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1"
            style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,255,255,0.1) transparent' }}>
            {decisions.length === 0 && (
              <div className="text-sm text-center py-8" style={{ color: 'rgba(255,255,255,0.3)' }}>
                No orchestrator decisions logged
              </div>
            )}
            {decisions.map((d, i) => (
              <DecisionCard key={d.decision_id || i} decision={d} index={i} />
            ))}
          </div>
        </motion.div>
      </div>

      {/* Inter-Agent Communication Legend */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="glass-card p-5"
      >
        <h3 className="font-display font-semibold text-white mb-4 text-sm">Inter-Agent Communication Bus — Event Types</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { event: 'bot_detected', sender: 'DeduplicationAgent', color: '#ff3b3b', desc: 'Emitted when review bot score exceeds threshold' },
            { event: 'low_confidence', sender: 'SentimentAgent', color: '#ffb800', desc: 'Triggers feedback loop evaluation by Orchestrator' },
            { event: 'emoji_found', sender: 'EmojiAgent', color: '#ffb800', desc: 'Emoji signals shared for confidence boosting' },
            { event: 'quality_check', sender: 'Orchestrator', color: '#bf5af2', desc: 'Broadcast after each phase for monitoring' },
          ].map(({ event, sender, color, desc }) => (
            <div key={event} className="rounded-xl p-3"
              style={{ background: `${color}08`, border: `1px solid ${color}20` }}>
              <div className="text-xs font-mono mb-1" style={{ color }}>{event}</div>
              <div className="text-xs mb-1" style={{ color: 'rgba(255,255,255,0.4)' }}>from: {sender}</div>
              <div className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.35)' }}>{desc}</div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}
