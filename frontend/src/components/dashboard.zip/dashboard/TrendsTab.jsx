import { useState } from 'react'
import { motion } from 'framer-motion'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { AlertTriangle, TrendingUp, TrendingDown, Zap } from 'lucide-react'
import { useReviewStore } from '../../store/reviewStore'
import clsx from 'clsx'

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="px-4 py-3 rounded-xl text-xs"
      style={{ background: 'rgba(22,27,34,0.95)', border: '1px solid rgba(0,245,255,0.2)', backdropFilter: 'blur(12px)' }}>
      <div className="font-semibold text-white mb-2">Window {label}</div>
      {payload.map(p => (
        <div key={p.dataKey} className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span style={{ color: 'rgba(255,255,255,0.6)' }}>{p.name}:</span>
          <span className="font-semibold text-white">{p.value}%</span>
        </div>
      ))}
    </div>
  )
}

const SEVERITY_STYLES = {
  critical: { bg: 'rgba(255,59,59,0.08)', border: 'rgba(255,59,59,0.3)', color: '#ff3b3b', icon: AlertTriangle },
  warning: { bg: 'rgba(255,184,0,0.08)', border: 'rgba(255,184,0,0.3)', color: '#ffb800', icon: TrendingDown },
  info: { bg: 'rgba(57,255,20,0.08)', border: 'rgba(57,255,20,0.3)', color: '#39ff14', icon: TrendingUp },
}

const LINE_COLORS = ['#00f5ff', '#ff3b3b', '#39ff14', '#ffb800', '#bf5af2', '#ff006e']

export default function TrendsTab() {
  const { report, getTrendChartData } = useReviewStore()
  const [selectedFeatureFilter, setSelectedFeatureFilter] = useState('packaging')
  if (!report) return null

  const alerts = report.trend_alerts || []
  const trendChartData = getTrendChartData()

  // Collect all feature keys from trend data
  const allFeatureKeys = new Set()
  trendChartData.forEach(w => {
    Object.keys(w).forEach(k => {
      if (k.endsWith('_complaints') || k.endsWith('_praises')) allFeatureKeys.add(k)
    })
  })

  // Get unique features from trend data
  const trendFeatures = [...new Set([...allFeatureKeys].map(k => k.replace('_complaints', '').replace('_praises', '')))]

  // Build per-feature trend chart data
  const featureTrendData = trendChartData.map(w => {
    const entry = { window: `W${w.window}`, reviews: `${w.windowStart}-${w.windowEnd}` }
    const complaintKey = `${selectedFeatureFilter}_complaints`
    const praiseKey = `${selectedFeatureFilter}_praises`
    if (w[complaintKey] !== undefined) entry.complaints = w[complaintKey]
    if (w[praiseKey] !== undefined) entry.praises = w[praiseKey]
    return entry
  }).filter(e => e.complaints !== undefined || e.praises !== undefined)

  return (
    <div className="space-y-6">
      {/* Alert banner count */}
      <div className="flex items-center gap-4 flex-wrap">
        {['critical', 'warning', 'info'].map(sev => {
          const count = alerts.filter(a => a.severity === sev).length
          const { color } = SEVERITY_STYLES[sev]
          return (
            <div key={sev} className="flex items-center gap-2 px-4 py-2 rounded-xl"
              style={{ background: `${color}10`, border: `1px solid ${color}25` }}>
              <div className="w-2 h-2 rounded-full" style={{ background: color }} />
              <span className="text-sm capitalize" style={{ color }}>{count} {sev}</span>
            </div>
          )
        })}
        {alerts.length === 0 && (
          <div className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>
            No trend alerts detected for this dataset
          </div>
        )}
      </div>

      {/* Alert cards */}
      {alerts.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-display font-semibold text-white">Active Trend Alerts</h3>
          {alerts.map(alert => {
            const { bg, border, color, icon: Icon } = SEVERITY_STYLES[alert.severity] || SEVERITY_STYLES.info
            return (
              <motion.div
                key={alert.alert_id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card p-5"
                style={{ background: bg, borderColor: border }}
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${color}15`, border: `1px solid ${color}25` }}>
                    <Icon size={18} style={{ color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-semibold text-white capitalize">
                        {alert.feature.replace(/_/g, ' ')}
                      </span>
                      <span className="px-2 py-0.5 rounded text-xs font-mono capitalize"
                        style={{ background: `${color}15`, color, border: `1px solid ${color}25` }}>
                        {alert.alert_type.replace(/_/g, ' ')}
                      </span>
                      {alert.is_systemic && (
                        <span className="px-2 py-0.5 rounded text-xs font-mono"
                          style={{ background: 'rgba(255,59,59,0.15)', color: '#ff3b3b', border: '1px solid rgba(255,59,59,0.3)' }}>
                          SYSTEMIC
                        </span>
                      )}
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.6)' }}>
                      {alert.description}
                    </p>
                    {alert.affected_reviews?.length > 0 && (
                      <div className="mt-2 text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>
                        Affecting reviews: {alert.affected_reviews.slice(0, 5).join(', ')}
                        {alert.affected_reviews.length > 5 && ` +${alert.affected_reviews.length - 5} more`}
                      </div>
                    )}
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-2xl font-bold font-display" style={{ color }}>
                      {alert.change_percent > 0 ? '+' : ''}{alert.change_percent}%
                    </div>
                    <div className="text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>
                      {Math.round(alert.previous_rate * 100)}% → {Math.round(alert.current_rate * 100)}%
                    </div>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Time series chart */}
      {featureTrendData.length > 1 && (
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <div>
              <h3 className="font-display font-semibold text-white">Feature Trend Over Batches</h3>
              <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
                Complaint vs praise rate across sliding windows of {report.processed_reviews?.length > 100 ? 50 : 10} reviews
              </p>
            </div>
            {/* Feature selector */}
            <div className="flex gap-2 flex-wrap">
              {trendFeatures.slice(0, 6).map((feat, i) => (
                <button
                  key={feat}
                  onClick={() => setSelectedFeatureFilter(feat)}
                  className={clsx(
                    'px-3 py-1.5 rounded-lg text-xs font-medium transition-all capitalize',
                    selectedFeatureFilter === feat ? 'text-white' : 'text-gray-400 hover:text-gray-200'
                  )}
                  style={selectedFeatureFilter === feat ? {
                    background: `${LINE_COLORS[i % LINE_COLORS.length]}20`,
                    border: `1px solid ${LINE_COLORS[i % LINE_COLORS.length]}40`,
                    color: LINE_COLORS[i % LINE_COLORS.length],
                  } : {
                    background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(255,255,255,0.07)',
                  }}
                >
                  {feat.replace(/_/g, ' ')}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={featureTrendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="window" tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} />
              <YAxis tick={{ fontSize: 11, fill: 'rgba(255,255,255,0.4)' }} domain={[0, 100]} unit="%" />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)' }} />
              <Line type="monotone" dataKey="complaints" name="Complaint %" stroke="#ff3b3b" strokeWidth={2} dot={{ r: 4, fill: '#ff3b3b' }} activeDot={{ r: 6 }} />
              <Line type="monotone" dataKey="praises" name="Praise %" stroke="#39ff14" strokeWidth={2} dot={{ r: 4, fill: '#39ff14' }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
          {/* Annotation for seeded trend */}
          {selectedFeatureFilter === 'packaging' && featureTrendData.length >= 2 && (
            <div className="mt-3 px-3 py-2 rounded-lg text-xs flex items-center gap-2"
              style={{ background: 'rgba(255,59,59,0.06)', border: '1px solid rgba(255,59,59,0.2)', color: '#ff3b3b' }}>
              <Zap size={11} />
              Seeded complaint trend detected — packaging complaints spike in the last review batch, as expected
            </div>
          )}
        </div>
      )}

      {/* Isolated vs systemic breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glass-card p-5">
          <h4 className="font-semibold text-white mb-3">Systemic Issues</h4>
          <div className="space-y-2">
            {alerts.filter(a => a.is_systemic).length === 0 ? (
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>No systemic issues detected</p>
            ) : (
              alerts.filter(a => a.is_systemic).map(a => (
                <div key={a.alert_id} className="flex items-center gap-3 px-3 py-2 rounded-lg"
                  style={{ background: 'rgba(255,59,59,0.06)', border: '1px solid rgba(255,59,59,0.15)' }}>
                  <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: '#ff3b3b' }} />
                  <span className="text-sm capitalize text-white">{a.feature.replace(/_/g, ' ')}</span>
                  <span className="ml-auto text-xs font-mono" style={{ color: '#ff3b3b' }}>
                    {Math.round(a.current_rate * 100)}%
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
        <div className="glass-card p-5">
          <h4 className="font-semibold text-white mb-3">Emerging (Isolated) Issues</h4>
          <div className="space-y-2">
            {alerts.filter(a => !a.is_systemic && a.severity !== 'info').length === 0 ? (
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>No isolated issues detected</p>
            ) : (
              alerts.filter(a => !a.is_systemic && a.severity !== 'info').map(a => (
                <div key={a.alert_id} className="flex items-center gap-3 px-3 py-2 rounded-lg"
                  style={{ background: 'rgba(255,184,0,0.06)', border: '1px solid rgba(255,184,0,0.15)' }}>
                  <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: '#ffb800' }} />
                  <span className="text-sm capitalize text-white">{a.feature.replace(/_/g, ' ')}</span>
                  <span className="ml-auto text-xs font-mono" style={{ color: '#ffb800' }}>
                    +{a.change_percent}%
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
