import { motion } from 'framer-motion'
import { useReviewStore } from '../../store/reviewStore'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie
} from 'recharts'
import { Smile, TrendingUp, Zap, Heart } from 'lucide-react'

const SENTIMENT_COLORS = {
  positive: '#39ff14',
  negative: '#ff3b3b',
  neutral: '#8b949e',
}

const SENTIMENT_BG = {
  positive: 'rgba(57,255,20,0.12)',
  negative: 'rgba(255,59,59,0.12)',
  neutral: 'rgba(139,148,158,0.12)',
}

function EmojiBar({ emoji, count, sentiment, maxCount }) {
  const pct = (count / maxCount) * 100
  const color = SENTIMENT_COLORS[sentiment] || '#8b949e'

  return (
    <div className="flex items-center gap-3 group">
      <span className="text-2xl w-8 text-center flex-shrink-0">{emoji}</span>
      <div className="flex-1 relative h-6 rounded overflow-hidden"
        style={{ background: 'rgba(255,255,255,0.04)' }}>
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: 'easeOut', delay: Math.random() * 0.3 }}
          className="h-full rounded"
          style={{ background: `${color}50` }}
        />
        <div className="absolute inset-0 flex items-center px-2.5">
          <span className="text-xs text-white font-medium">{count}</span>
        </div>
      </div>
      <span className="text-xs w-20 flex-shrink-0 capitalize"
        style={{ color: color }}>{sentiment}</span>
    </div>
  )
}

export default function EmojiAnalysisTab() {
  const { getEmojiData } = useReviewStore()
  const emojiData = getEmojiData()

  if (!emojiData) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="text-5xl mb-4">😶</div>
        <h3 className="font-display font-semibold text-white mb-2">No Emoji Data</h3>
        <p className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>
          No emojis were detected in the uploaded reviews.
        </p>
      </div>
    )
  }

  const { topEmojis, total_emojis_found, unique_emojis, reviews_with_emojis,
    emoji_confidence_boosts_applied, emoji_sentiment_distribution,
    top_positive_emojis, top_negative_emojis } = emojiData

  const maxCount = topEmojis[0]?.count || 1

  const sentimentPieData = Object.entries(emoji_sentiment_distribution || {})
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({
      name,
      value: Math.round(value * 100),
      color: SENTIMENT_COLORS[name] || '#8b949e',
    }))

  return (
    <div className="space-y-6">
      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Smile, label: 'Total Emojis', val: total_emojis_found, color: '#ffb800', sub: 'across all reviews' },
          { icon: TrendingUp, label: 'Unique Emojis', val: unique_emojis, color: '#00f5ff', sub: 'distinct signals' },
          { icon: Heart, label: 'Reviews with Emojis', val: reviews_with_emojis, color: '#ff006e', sub: 'emoji-rich reviews' },
          { icon: Zap, label: 'Confidence Boosts', val: emoji_confidence_boosts_applied, color: '#39ff14', sub: 'applied to sentiment' },
        ].map(({ icon: Icon, label, val, color, sub }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
            className="glass-card p-5"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: `${color}15`, border: `1px solid ${color}25` }}>
                <Icon size={15} style={{ color }} />
              </div>
            </div>
            <div className="font-display font-bold text-3xl text-white">{val}</div>
            <div className="text-xs font-medium mt-1 text-white opacity-70">{label}</div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.3)' }}>{sub}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Emojis Chart */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
          className="glass-card p-6 lg:col-span-2"
        >
          <h3 className="font-display font-semibold text-white mb-1">Top Emojis by Frequency</h3>
          <p className="text-xs mb-5" style={{ color: 'rgba(255,255,255,0.35)' }}>
            Emoji signals mapped to sentiment — used to boost confidence scores
          </p>
          <div className="space-y-2.5">
            {topEmojis.slice(0, 12).map((item, i) => (
              <EmojiBar
                key={item.emoji}
                emoji={item.emoji}
                count={item.count}
                sentiment={item.sentiment}
                maxCount={maxCount}
              />
            ))}
            {topEmojis.length === 0 && (
              <p className="text-sm text-center py-6" style={{ color: 'rgba(255,255,255,0.3)' }}>
                No emojis found in reviews
              </p>
            )}
          </div>
        </motion.div>

        {/* Emoji Sentiment Pie */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.25 }}
          className="glass-card p-6"
        >
          <h3 className="font-display font-semibold text-white mb-1">Emoji Sentiment Split</h3>
          <p className="text-xs mb-4" style={{ color: 'rgba(255,255,255,0.35)' }}>
            Distribution of emoji emotional signals
          </p>

          {sentimentPieData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie
                    data={sentimentPieData}
                    cx="50%" cy="50%"
                    innerRadius={45} outerRadius={70}
                    paddingAngle={3} dataKey="value"
                  >
                    {sentimentPieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} stroke="transparent" />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: 'rgba(22,27,34,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                    labelStyle={{ color: 'white' }}
                    formatter={(val) => [`${val}%`, '']}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-2">
                {sentimentPieData.map(d => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                      <span className="text-xs capitalize" style={{ color: 'rgba(255,255,255,0.6)' }}>{d.name}</span>
                    </div>
                    <span className="text-xs font-semibold" style={{ color: d.color }}>{d.value}%</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-10 text-sm" style={{ color: 'rgba(255,255,255,0.3)' }}>
              No emoji sentiment data
            </div>
          )}
        </motion.div>
      </div>

      {/* Positive vs Negative Highlight */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card p-5"
          style={{ border: '1px solid rgba(57,255,20,0.15)' }}
        >
          <h4 className="font-display font-semibold mb-3" style={{ color: '#39ff14' }}>
            😊 Top Positive Emojis
          </h4>
          {top_positive_emojis.length > 0 ? (
            <div className="flex flex-wrap gap-3">
              {top_positive_emojis.map(e => (
                <span key={e} className="text-3xl hover:scale-125 transition-transform cursor-default" title="Positive signal">{e}</span>
              ))}
            </div>
          ) : (
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>No positive emojis detected</p>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.38 }}
          className="glass-card p-5"
          style={{ border: '1px solid rgba(255,59,59,0.15)' }}
        >
          <h4 className="font-display font-semibold mb-3" style={{ color: '#ff3b3b' }}>
            😡 Top Negative Emojis
          </h4>
          {top_negative_emojis.length > 0 ? (
            <div className="flex flex-wrap gap-3">
              {top_negative_emojis.map(e => (
                <span key={e} className="text-3xl hover:scale-125 transition-transform cursor-default" title="Negative signal">{e}</span>
              ))}
            </div>
          ) : (
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>No negative emojis detected</p>
          )}
        </motion.div>
      </div>

      {/* Confidence Boost Explainer */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass-card p-5"
        style={{ border: '1px solid rgba(0,245,255,0.1)' }}
      >
        <h4 className="font-display font-semibold text-white mb-2 text-sm">How Emoji Confidence Boosting Works</h4>
        <p className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.5)' }}>
          When a review contains emojis that <strong style={{ color: '#39ff14' }}>align with</strong> its text sentiment
          (e.g., 😍 in a positive review), the sentiment confidence score is boosted by up to +0.20.
          When emojis <strong style={{ color: '#ff3b3b' }}>conflict</strong> with text sentiment
          (e.g., 😡 in text labeled as positive), a penalty is applied.
          This makes the overall confidence score more accurate and data-driven.
        </p>
      </motion.div>
    </div>
  )
}
